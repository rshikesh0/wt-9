require("dotenv").config();

const path = require("path");
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");

const feedbackRoutes = require("./backend/routes/feedbackRoutes");
const errorHandler = require("./backend/middleware/errorHandler");

const app = express();

const PORT = process.env.PORT || 3000;

// -----------------------------
// Security middleware
// -----------------------------
app.use(
    helmet({
        contentSecurityPolicy: {
            directives: {
                defaultSrc: ["'self'"],
                scriptSrc: ["'self'", "'unsafe-inline'"],
                styleSrc: ["'self'", "'unsafe-inline'"],
                imgSrc: ["'self'", "data:"],
                connectSrc: ["'self'"],
                objectSrc: ["'none'"],
                baseUri: ["'self'"],
                formAction: ["'self'"]
            }
        }
    })
);
// -----------------------------
// CORS
// -----------------------------

app.use(
    cors({
        origin: true
    })
);

// -----------------------------
// Body parsing
// -----------------------------

app.use(
    express.json({
        limit: "10kb"
    })
);

app.use(
    express.urlencoded({
        extended: false,
        limit: "10kb"
    })
);

// -----------------------------
// Static frontend
// -----------------------------

app.use(
    express.static(
        path.join(__dirname, "frontend")
    )
);

// -----------------------------
// Health check
// -----------------------------

app.get("/api/health", (req, res) => {
    res.status(200).json({
        success: true,
        message: "Server is running."
    });
});

// -----------------------------
// API routes
// -----------------------------

app.use("/api/feedback", feedbackRoutes);

// -----------------------------
// 404 handler
// -----------------------------

app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: "Route not found."
    });
});

// -----------------------------
// Global error handler
// -----------------------------

app.use(errorHandler);

// -----------------------------
// Start server
// -----------------------------

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});