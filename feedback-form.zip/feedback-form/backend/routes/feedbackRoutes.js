const express = require("express");

const {
    createFeedback,
    getFeedback
} = require("../controllers/feedbackController");

const validateFeedback = require("../middleware/validateFeedback");

const router = express.Router();

router.post("/", validateFeedback, createFeedback);

router.get("/", getFeedback);

module.exports = router;