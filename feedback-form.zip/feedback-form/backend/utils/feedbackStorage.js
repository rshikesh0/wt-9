const fs = require("fs/promises");
const path = require("path");

const dataDirectory = path.join(__dirname, "../../data");
const feedbackFile = path.join(dataDirectory, "feedback.json");

async function ensureStorageExists() {
    await fs.mkdir(dataDirectory, { recursive: true });

    try {
        await fs.access(feedbackFile);
    } catch {
        await fs.writeFile(feedbackFile, "[]", "utf8");
    }
}

async function readFeedback() {
    await ensureStorageExists();

    const fileContents = await fs.readFile(feedbackFile, "utf8");

    try {
        return JSON.parse(fileContents);
    } catch {
        throw new Error("Feedback storage contains invalid JSON.");
    }
}

async function saveFeedback(feedback) {
    const feedbackList = await readFeedback();

    feedbackList.push(feedback);

    await fs.writeFile(
        feedbackFile,
        JSON.stringify(feedbackList, null, 2),
        "utf8"
    );

    return feedback;
}

module.exports = {
    readFeedback,
    saveFeedback
};