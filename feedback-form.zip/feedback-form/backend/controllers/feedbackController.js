const { randomUUID } = require("crypto");

const {
    saveFeedback,
    readFeedback
} = require("../utils/feedbackStorage");


async function createFeedback(req, res, next) {

    console.log("=================================");
    console.log("ACADEMIC FEEDBACK REQUEST");
    console.log("Request body:", req.body);
    console.log("=================================");

    try {

        const {
            studentName,
            studentEmail,
            department,
            semester,
            course,
            faculty,
            rating,
            feedbackType,
            comments
        } = req.body;


        const feedback = {

            id: randomUUID(),

            studentName,

            studentEmail,

            department,

            semester,

            course,

            faculty,

            rating,

            feedbackType,

            comments,

            createdAt: new Date().toISOString()

        };


        await saveFeedback(feedback);


        console.log(
            "Academic feedback saved successfully."
        );


        return res.status(201).json({

            success: true,

            message:
                "Academic feedback submitted successfully.",

            data: {
                id: feedback.id
            }

        });

    } catch (error) {

        console.error(
            "Error saving academic feedback:",
            error
        );

        next(error);
    }
}


async function getFeedback(req, res, next) {

    try {

        const feedback =
            await readFeedback();

        return res.status(200).json({

            success: true,

            data: feedback

        });

    } catch (error) {

        next(error);

    }
}


module.exports = {
    createFeedback,
    getFeedback
};