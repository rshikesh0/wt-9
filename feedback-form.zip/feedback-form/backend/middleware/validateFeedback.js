function validateFeedback(req, res, next) {

    const {
        studentName,
        studentEmail,
        department,
        semester,
        course,
        faculty,
        rating,
        feedbackType,
        comments
    } = req.body;

    const errors = {};

    // Student name
    if (
        typeof studentName !== "string" ||
        studentName.trim().length < 2
    ) {
        errors.studentName =
            "Student name must contain at least 2 characters.";
    }

    if (
        typeof studentName === "string" &&
        studentName.trim().length > 100
    ) {
        errors.studentName =
            "Student name cannot exceed 100 characters.";
    }


    // Email
    if (
        typeof studentEmail !== "string" ||
        studentEmail.trim().length === 0
    ) {
        errors.studentEmail = "Student email is required.";
    } else {

        const emailRegex =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailRegex.test(studentEmail.trim())) {
            errors.studentEmail =
                "Please provide a valid email address.";
        }
    }


    // Department
    const allowedDepartments = [
        "Computer Engineering",
        "Information Technology",
        "Electronics Engineering",
        "Mechanical Engineering",
        "Civil Engineering",
        "Other"
    ];

    if (!allowedDepartments.includes(department)) {
        errors.department =
            "Please select a valid department.";
    }


    // Semester
    const allowedSemesters = [
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8"
    ];

    if (!allowedSemesters.includes(semester)) {
        errors.semester =
            "Please select a valid semester.";
    }


    // Course
    if (
        typeof course !== "string" ||
        course.trim().length < 2
    ) {
        errors.course =
            "Course name is required.";
    }


    // Faculty
    if (
        typeof faculty !== "string" ||
        faculty.trim().length < 2
    ) {
        errors.faculty =
            "Faculty name is required.";
    }


    // Rating
    const numericRating = Number(rating);

    if (
        !Number.isInteger(numericRating) ||
        numericRating < 1 ||
        numericRating > 5
    ) {
        errors.rating =
            "Rating must be between 1 and 5.";
    }


    // Feedback type
    const allowedFeedbackTypes = [
        "Teaching Quality",
        "Course Content",
        "Practical/Lab",
        "Assessment",
        "Infrastructure",
        "General"
    ];

    if (!allowedFeedbackTypes.includes(feedbackType)) {
        errors.feedbackType =
            "Please select a valid feedback type.";
    }


    // Comments
    if (
        typeof comments !== "string" ||
        comments.trim().length < 10
    ) {
        errors.comments =
            "Feedback must contain at least 10 characters.";
    }

    if (
        typeof comments === "string" &&
        comments.trim().length > 2000
    ) {
        errors.comments =
            "Feedback cannot exceed 2000 characters.";
    }


    // Return validation errors
    if (Object.keys(errors).length > 0) {

        return res.status(400).json({
            success: false,
            message: "Please correct the following errors.",
            errors
        });

    }


    // Normalize data

    req.body.studentName =
        studentName.trim();

    req.body.studentEmail =
        studentEmail.trim().toLowerCase();

    req.body.course =
        course.trim();

    req.body.faculty =
        faculty.trim();

    req.body.comments =
        comments.trim();

    req.body.rating =
        numericRating;


    next();
}


module.exports = validateFeedback;