const router = require("express").Router();
const controller = require("../controllers/projectController");
const { validateProject, validateBody } = require("../middleware/validate");

router.get("/", controller.list);
router.post("/", validateBody(validateProject), controller.create);
router.patch("/:id/status", controller.updateStatus);

module.exports = router;
