const router = require("express").Router();
const controller = require("../controllers/invoiceController");
const { validateInvoice, validateBody } = require("../middleware/validate");

router.get("/", controller.list);
router.post("/", validateBody(validateInvoice), controller.create);
router.post("/:id/payments", controller.addPayment);

module.exports = router;
