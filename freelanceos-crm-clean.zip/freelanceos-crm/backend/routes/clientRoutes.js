const router = require("express").Router();
const controller = require("../controllers/clientController");
const { validateClient, validateBody } = require("../middleware/validate");

router.get("/", controller.list);
router.post("/", validateBody(validateClient), controller.create);
router.patch("/:id/convert", controller.convert);

module.exports = router;
