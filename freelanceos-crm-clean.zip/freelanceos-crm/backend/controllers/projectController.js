const crm = require("../services/crmService");

async function list(_req, res) {
  res.json({ success: true, data: await crm.listProjects() });
}

async function create(req, res) {
  const project = await crm.createProject(req.body);
  res.status(201).json({ success: true, message: "Project saved.", data: project });
}

async function updateStatus(req, res) {
  const project = await crm.updateProjectStatus(req.params.id, req.body.status);
  res.json({ success: true, message: "Project status updated.", data: project });
}

module.exports = { list, create, updateStatus };
