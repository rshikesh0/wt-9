const crm = require("../services/crmService");

async function list(_req, res) {
  res.json({ success: true, data: await crm.listInvoices() });
}

async function create(req, res) {
  const invoice = await crm.createInvoice(req.body);
  res.status(201).json({ success: true, message: "Invoice created.", data: invoice });
}

async function addPayment(req, res) {
  const invoice = await crm.addPayment(req.params.id, req.body);
  res.status(201).json({ success: true, message: "Payment recorded.", data: invoice });
}

module.exports = { list, create, addPayment };
