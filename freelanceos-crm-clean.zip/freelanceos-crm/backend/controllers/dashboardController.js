const crm = require("../services/crmService");

async function summary(_req, res) {
  res.json({ success: true, data: await crm.getDashboard() });
}

module.exports = { summary };
