const crm = require("../services/crmService");

async function list(_req, res) {
  res.json({ success: true, data: await crm.listClients() });
}

async function create(req, res) {
  const client = await crm.createClient(req.body);
  res.status(201).json({ success: true, message: "Contact saved.", data: client });
}

async function convert(req, res) {
  const client = await crm.convertLead(req.params.id);
  res.json({ success: true, message: "Contact type updated.", data: client });
}

module.exports = { list, create, convert };
