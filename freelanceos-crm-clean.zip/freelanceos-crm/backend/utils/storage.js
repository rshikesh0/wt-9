const fs = require("fs/promises");
const path = require("path");

const DATA_DIR = path.join(__dirname, "../../data");
const FILES = {
  clients: "clients.json",
  projects: "projects.json",
  invoices: "invoices.json"
};

function getFilePath(collection) {
  const filename = FILES[collection];
  if (!filename) throw new Error(`Unknown data collection: ${collection}`);
  return path.join(DATA_DIR, filename);
}

async function readAll(collection) {
  const filePath = getFilePath(collection);
  const content = await fs.readFile(filePath, "utf8");
  const records = JSON.parse(content);

  if (!Array.isArray(records)) {
    throw new Error(`${FILES[collection]} must contain a JSON array.`);
  }

  return records;
}

// Write to a temporary file first, then replace the original file.
async function writeAll(collection, records) {
  const filePath = getFilePath(collection);
  const temporaryPath = `${filePath}.tmp`;

  await fs.writeFile(temporaryPath, JSON.stringify(records, null, 2), "utf8");
  await fs.rename(temporaryPath, filePath);
  return records;
}

async function addOne(collection, record) {
  const records = await readAll(collection);
  records.push(record);
  await writeAll(collection, records);
  return record;
}

async function initialiseStorage() {
  await fs.mkdir(DATA_DIR, { recursive: true });

  for (const collection of Object.keys(FILES)) {
    try {
      await fs.access(getFilePath(collection));
    } catch {
      await writeAll(collection, []);
    }
  }
}

module.exports = { readAll, writeAll, addOne, initialiseStorage };
