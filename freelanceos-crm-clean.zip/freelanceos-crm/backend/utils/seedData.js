const { randomUUID } = require("crypto");
const { readAll, writeAll, initialiseStorage } = require("./storage");

async function initialiseData() {
  await initialiseStorage();

  const [clients, projects, invoices] = await Promise.all([
    readAll("clients"),
    readAll("projects"),
    readAll("invoices")
  ]);

  // Keep existing records. Add demo records only to a completely empty workspace.
  if (clients.length || projects.length || invoices.length) return;

  const clientId = randomUUID();
  const projectId = randomUUID();
  const today = new Date();
  const dateIn = (days) => {
    const date = new Date(today);
    date.setDate(date.getDate() + days);
    return date.toISOString().slice(0, 10);
  };

  await writeAll("clients", [
    { id: clientId, name: "Aarav Mehta", email: "aarav@example.com", company: "Northstar Studio", type: "client", notes: "Website redesign client", createdAt: today.toISOString() },
    { id: randomUUID(), name: "Mira Shah", email: "mira@example.com", company: "Mira Creative", type: "lead", notes: "Asked about a brand identity package", createdAt: today.toISOString() }
  ]);

  await writeAll("projects", [
    { id: projectId, clientId, name: "Website redesign", fee: 45000, startDate: dateIn(-7), dueDate: dateIn(9), status: "in-progress", createdAt: today.toISOString() }
  ]);

  await writeAll("invoices", [
    { id: randomUUID(), invoiceNumber: "INV-1001", clientId, projectId, issueDate: dateIn(-5), dueDate: dateIn(10), amount: 45000, payments: [{ id: randomUUID(), amount: 15000, date: dateIn(-2), method: "UPI", createdAt: today.toISOString() }], notes: "First milestone invoice", createdAt: today.toISOString() }
  ]);
}

module.exports = { initialiseData };
