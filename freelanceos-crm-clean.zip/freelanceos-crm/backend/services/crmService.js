const { randomUUID } = require("crypto");
const { readAll, writeAll, addOne } = require("../utils/storage");
const httpError = require("../utils/httpError");
const { isMoney, isDate } = require("../middleware/validate");

const today = () => new Date().toISOString().slice(0, 10);
const now = () => new Date().toISOString();
const byId = (records, id) => records.find((record) => record.id === id);

// CLIENTS ---------------------------------------------------------------
async function listClients() {
  const clients = await readAll("clients");
  return clients.sort((a, b) => a.name.localeCompare(b.name));
}

async function createClient(data) {
  const clients = await readAll("clients");
  const email = data.email.trim().toLowerCase();

  if (clients.some((client) => client.email.toLowerCase() === email)) {
    throw httpError(409, "A contact with this email already exists.");
  }

  const client = {
    id: randomUUID(),
    name: data.name.trim(),
    email,
    company: (data.company || "").trim(),
    type: data.type,
    notes: (data.notes || "").trim(),
    createdAt: now()
  };

  await addOne("clients", client);
  return client;
}

async function convertLead(id) {
  const clients = await readAll("clients");
  const client = byId(clients, id);

  if (!client) throw httpError(404, "Contact not found.");
  client.type = "client";
  client.updatedAt = now();
  await writeAll("clients", clients);
  return client;
}

// PROJECTS --------------------------------------------------------------
async function listProjects() {
  const [projects, clients] = await Promise.all([
    readAll("projects"),
    readAll("clients")
  ]);

  return projects
    .map((project) => ({
      ...project,
      clientName: byId(clients, project.clientId)?.name || "Unknown client"
    }))
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate));
}

async function createProject(data) {
  const clients = await readAll("clients");
  const client = byId(clients, data.clientId);

  if (!client || client.type !== "client") {
    throw httpError(400, "Choose a saved client. Convert a lead before creating a project.");
  }

  const project = {
    id: randomUUID(),
    clientId: data.clientId,
    name: data.name.trim(),
    fee: Number(data.fee),
    startDate: data.startDate,
    dueDate: data.dueDate,
    status: data.status,
    createdAt: now()
  };

  await addOne("projects", project);
  return project;
}

async function updateProjectStatus(id, status) {
  const allowedStatuses = ["planned", "in-progress", "review", "completed", "on-hold"];
  if (!allowedStatuses.includes(status)) throw httpError(400, "Choose a valid project status.");

  const projects = await readAll("projects");
  const project = byId(projects, id);
  if (!project) throw httpError(404, "Project not found.");

  project.status = status;
  project.updatedAt = now();
  await writeAll("projects", projects);
  return project;
}

// INVOICES AND PAYMENTS --------------------------------------------------
function getPaymentTotal(invoice) {
  return (invoice.payments || []).reduce((total, payment) => total + Number(payment.amount), 0);
}

function getInvoiceStatus(invoice, paid) {
  if (paid >= Number(invoice.amount)) return "paid";
  if (invoice.dueDate < today()) return "overdue";
  if (paid > 0) return "partial";
  return "unpaid";
}

async function listInvoices() {
  const [invoices, clients, projects] = await Promise.all([
    readAll("invoices"),
    readAll("clients"),
    readAll("projects")
  ]);

  return invoices.map((invoice) => {
    const project = byId(projects, invoice.projectId);
    const paid = getPaymentTotal(invoice);

    return {
      ...invoice,
      clientName: byId(clients, invoice.clientId)?.name || "Unknown client",
      projectName: project?.name || "Unknown project",
      paid,
      balance: Math.max(0, Number(invoice.amount) - paid),
      status: getInvoiceStatus(invoice, paid)
    };
  }).sort((a, b) => b.issueDate.localeCompare(a.issueDate));
}

async function createInvoice(data) {
  const [projects, invoices] = await Promise.all([
    readAll("projects"),
    readAll("invoices")
  ]);
  const project = byId(projects, data.projectId);

  if (!project) throw httpError(400, "Choose an existing project.");

  const number = invoices.reduce((highest, invoice) => {
    const current = Number(String(invoice.invoiceNumber).replace(/\D/g, "")) || 1000;
    return Math.max(highest, current);
  }, 1000) + 1;

  const invoice = {
    id: randomUUID(),
    invoiceNumber: `INV-${number}`,
    clientId: project.clientId,
    projectId: project.id,
    issueDate: data.issueDate,
    dueDate: data.dueDate,
    amount: Number(data.amount),
    payments: [],
    notes: (data.notes || "").trim(),
    createdAt: now()
  };

  await addOne("invoices", invoice);
  return invoice;
}

async function addPayment(invoiceId, data) {
  const amount = Number(data.amount);
  if (!isMoney(amount)) throw httpError(400, "Payment amount must be greater than zero.");
  if (!isDate(data.date)) throw httpError(400, "Enter a valid payment date.");
  if (!['UPI', 'Bank transfer', 'Cash', 'Card', 'Other'].includes(data.method)) {
    throw httpError(400, "Choose a valid payment method.");
  }

  const invoices = await readAll("invoices");
  const invoice = byId(invoices, invoiceId);
  if (!invoice) throw httpError(404, "Invoice not found.");

  const remaining = Number(invoice.amount) - getPaymentTotal(invoice);
  if (amount > remaining) throw httpError(400, "Payment cannot be greater than the outstanding balance.");

  invoice.payments.push({
    id: randomUUID(),
    amount,
    date: data.date,
    method: data.method,
    createdAt: now()
  });

  await writeAll("invoices", invoices);
  return invoice;
}

// DASHBOARD -------------------------------------------------------------
async function getDashboard() {
  const [clients, projects, invoices] = await Promise.all([
    readAll("clients"),
    readAll("projects"),
    listInvoices()
  ]);

  const activeProjects = projects.filter((project) =>
    !["completed", "on-hold"].includes(project.status)
  );
  const overdueInvoices = invoices.filter((invoice) => invoice.status === "overdue");
  const revenueCollected = invoices.reduce((sum, invoice) => sum + invoice.paid, 0);
  const outstanding = invoices.reduce((sum, invoice) => sum + invoice.balance, 0);

  return {
    stats: {
      clients: clients.filter((client) => client.type === "client").length,
      leads: clients.filter((client) => client.type === "lead").length,
      activeProjects: activeProjects.length,
      revenueCollected,
      outstanding,
      overdueCount: overdueInvoices.length
    },
    upcomingProjects: activeProjects
      .filter((project) => project.dueDate >= today())
      .sort((a, b) => a.dueDate.localeCompare(b.dueDate))
      .slice(0, 5),
    overdueInvoices: overdueInvoices.slice(0, 5)
  };
}

module.exports = {
  listClients,
  createClient,
  convertLead,
  listProjects,
  createProject,
  updateProjectStatus,
  listInvoices,
  createInvoice,
  addPayment,
  getDashboard
};
