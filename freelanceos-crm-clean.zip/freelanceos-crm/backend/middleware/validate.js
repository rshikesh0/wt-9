function isText(value) {
  return typeof value === "string" && value.trim().length > 0;
}

function isMoney(value) {
  return value !== "" && Number.isFinite(Number(value)) && Number(value) > 0;
}

function isDate(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

function validateClient(data) {
  const errors = {};
  if (!isText(data.name)) errors.name = "Enter a name.";
  if (!isText(data.email) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = "Enter a valid email address.";
  }
  if (!['lead', 'client'].includes(data.type)) errors.type = "Choose lead or client.";
  return errors;
}

function validateProject(data) {
  const errors = {};
  if (!isText(data.name)) errors.name = "Enter a project name.";
  if (!isText(data.clientId)) errors.clientId = "Choose a client.";
  if (!isMoney(data.fee)) errors.fee = "Fee must be greater than zero.";
  if (!isDate(data.startDate)) errors.startDate = "Choose a valid start date.";
  if (!isDate(data.dueDate)) errors.dueDate = "Choose a valid due date.";
  if (isDate(data.startDate) && isDate(data.dueDate) && data.dueDate < data.startDate) {
    errors.dueDate = "Due date cannot be before the start date.";
  }
  if (!['planned', 'in-progress', 'review', 'completed', 'on-hold'].includes(data.status)) {
    errors.status = "Choose a valid project status.";
  }
  return errors;
}

function validateInvoice(data) {
  const errors = {};
  if (!isText(data.projectId)) errors.projectId = "Choose a project.";
  if (!isMoney(data.amount)) errors.amount = "Invoice amount must be greater than zero.";
  if (!isDate(data.issueDate)) errors.issueDate = "Choose a valid issue date.";
  if (!isDate(data.dueDate)) errors.dueDate = "Choose a valid due date.";
  if (isDate(data.issueDate) && isDate(data.dueDate) && data.dueDate < data.issueDate) {
    errors.dueDate = "Due date cannot be before the issue date.";
  }
  return errors;
}

function validateBody(validator) {
  return (req, res, next) => {
    const errors = validator(req.body || {});
    if (Object.keys(errors).length) {
      return res.status(400).json({
        success: false,
        message: "Please check the form fields.",
        errors
      });
    }
    next();
  };
}

module.exports = { validateClient, validateProject, validateInvoice, validateBody, isMoney, isDate };
