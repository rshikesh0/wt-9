# FreelanceOS — Codebase and Presentation Guide

## 1. What does the app do?

FreelanceOS is a small CRM (Customer Relationship Management system) for a freelancer. It keeps related business information in one place:

1. **Contacts** — potential clients (leads) and existing clients.
2. **Projects** — work agreed with a client, its fee, status, and deadline.
3. **Invoices** — a request for payment for a project.
4. **Payments** — money received against an invoice, including partial payments.
5. **Overview** — summary numbers calculated from those records.

The goal is to stop tracking clients, deadlines, and payments across scattered notes or spreadsheets.

## 2. Architecture in one diagram

```text
User in browser
     |
     v
frontend/index.html + style.css
     |
     v
frontend/app.js  -- fetch() -->  Express API (server.js)
                                      |
                                      v
                                  routes/
                                      |
                                      v
                                controllers/
                                      |
                                      v
                            services/crmService.js
                         (rules + calculations)
                                      |
                                      v
                              utils/storage.js
                                      |
                                      v
                 data/clients.json, projects.json, invoices.json
```

A response travels back up the same path: the storage utility returns records, the service shapes or calculates the result, the controller sends JSON, and the frontend updates the screen.

## 3. What each important file is responsible for

### `server.js` — starts the application

This file creates the Express app and installs middleware:

- `helmet()` adds common HTTP security headers.
- `cors()` controls cross-origin browser requests. This project serves its frontend and API from the same server, so CORS is not essential for the current local setup; it is retained because it matches the reference stack.
- `express.json()` lets Express read JSON request bodies.
- `express.static()` serves `frontend/` files to the browser.

Then `server.js` registers each router under `/api/...`, handles unknown routes, installs the shared error handler, initialises the data files, and starts listening on port 3000.

### `frontend/index.html` — page structure

Contains the sidebar navigation, main page area, notice area, and payment dialog. The records are not hardcoded into the HTML; JavaScript loads them from the API.

### `frontend/style.css` — appearance

Contains colors, spacing, typography, cards, tables, forms, status labels, and responsive rules for narrow screens. It changes how the page looks, not the CRM business rules.

### `frontend/app.js` — browser behaviour

This file:

- Calls the API with `fetch()`.
- Stores the latest data in a small `state` object.
- Renders the selected screen (overview, contacts, projects, invoices).
- Handles form submissions, navigation, lead conversion, project status changes, and payment dialogs.
- Shows success or error messages.

The `api()` helper centralises HTTP requests and error handling. The `refresh()` function reloads all four API datasets, then `render()` redraws the current page.

### `backend/routes/` — URL map

Routes define which controller handles each HTTP method and path. For example, `POST /api/clients` means “create a contact.” Routes are intentionally small; they should not contain calculations or file operations.

### `backend/controllers/` — HTTP layer

A controller takes information from `req` (request), calls a service function, then sends a response with `res` (response). The controller is the bridge between HTTP and business logic. Express 5 forwards rejected promises from async route handlers to the error middleware.

### `backend/services/crmService.js` — business rules

This is the main logic file. It answers questions such as:

- Is the selected client real before a project can be created?
- Which client belongs to a project?
- What is the invoice's remaining balance?
- Is an invoice overdue, partially paid, unpaid, or fully paid?
- What numbers should appear on the overview screen?

Keeping this code out of the controllers makes the rules easier to find and explain.

### `backend/middleware/validate.js` — check submitted input

Validation checks the shape of incoming values before the controller runs. For example, a contact needs a name and valid email; an invoice needs a positive amount and sensible dates. The `validateBody()` function converts validation failures into a clear `400 Bad Request` response.

Validation is about input shape. The service still checks business rules, such as whether a selected client or project exists.

### `backend/utils/storage.js` — JSON persistence

This file reads and writes the three JSON arrays. `readAll()` loads records, `writeAll()` formats and saves them, and `addOne()` appends one record. `writeAll()` writes a temporary file before replacing the original so the final file is less likely to be left half-written if the process stops during a save.

### `backend/utils/seedData.js` — demonstration records

On startup, it ensures the JSON files exist. If all three collections are empty, it creates fictional sample data with valid links between a client, a project, and an invoice. It does not overwrite a non-empty workspace.

### `backend/middleware/errorHandler.js` and `backend/utils/httpError.js`

`httpError()` creates an error with an HTTP status, such as `404`. The central error handler converts errors into a consistent JSON response rather than duplicating that code in every controller.

### `tests/validate.test.js` — basic automatic checks

Uses Node's built-in test runner. It checks valid/invalid contact data, dates, positive amounts, and a project due-date rule. Run it using `npm test`.

## 4. Example: what happens when a contact is added?

1. The user fills in the Contacts form.
2. `frontend/app.js` catches the form's submit event and gathers its values with `FormData`.
3. The browser sends `POST /api/clients` with a JSON body.
4. `clientRoutes.js` matches the route and runs `validateBody(validateClient)`.
5. `clientController.create()` calls `crmService.createClient()`.
6. The service normalises the email, checks for duplicates, creates a unique ID, and calls `addOne("clients", client)`.
7. `storage.js` saves the contact in `data/clients.json`.
8. The controller returns `201 Created` and a success message.
9. The frontend reloads the data and redraws the contacts table.

A useful explanation sentence is: **“Routes choose the handler, controllers handle HTTP, services enforce business rules, and storage reads or writes the records.”**

## 5. Example: how does partial payment work?

Suppose an invoice is ₹45,000 and the client pays ₹15,000.

- `addPayment()` confirms the amount is positive, the date is valid, the payment method is allowed, and the invoice exists.
- It totals the payments already saved: ₹0.
- It checks that ₹15,000 does not exceed the ₹45,000 remaining balance.
- It adds a payment record to that invoice's `payments` array and saves the invoice file.
- When invoices are listed, `listInvoices()` calculates `paid = 15000` and `balance = 45000 - 15000 = 30000`.
- Since some money has been received but the balance is not zero, the invoice is labelled `partial` unless it is already past its due date, in which case it is labelled `overdue`.

The key design choice: the app stores the individual payments and calculates the total/balance from them. It avoids manually updating two separate totals that could become inconsistent.

## 6. Main data relationships

```text
clients.json
  id ----------------------+
                           |
projects.json              | clientId
  id                       |
  clientId ----------------+
  name                     |
  fee                      |
  dueDate                  |
       |
       | projectId
       v
invoices.json
  id
  projectId
  clientId
  amount
  dueDate
  payments: [ { amount, date, method } ]
```

IDs link records across files. The project stores `clientId`; an invoice stores the project and client IDs. Payments are nested under the invoice because, in this simple app, they belong to exactly one invoice.

## 7. API actions worth remembering

| Action | Request | Meaning |
|---|---|---|
| List contacts | `GET /api/clients` | Fetch all leads and clients |
| Add a contact | `POST /api/clients` | Validate and save a contact |
| Convert a lead | `PATCH /api/clients/:id/convert` | Change the contact type to client |
| Create a project | `POST /api/projects` | Link work to an existing client |
| Update status | `PATCH /api/projects/:id/status` | Save a project status change |
| Create invoice | `POST /api/invoices` | Link an invoice to a project |
| Add payment | `POST /api/invoices/:id/payments` | Record money received |
| Overview totals | `GET /api/dashboard` | Calculate summary figures |

`GET` reads data, `POST` creates a record, and `PATCH` updates part of an existing record.

## 8. A short presentation script for your lecturer

> “My project is FreelanceOS, a lightweight CRM designed for freelancers. It manages a simple workflow from a potential lead to a client, from a client to a project, and from a project to an invoice and its payments.
>
> The frontend uses HTML for structure, CSS for layout, and vanilla JavaScript for events and API calls. Node.js runs the backend and Express defines the REST API. I separated the backend into routes, controllers, services, and utilities so each part has one responsibility.
>
> Routes map URLs to controllers. Controllers handle request and response objects. The service layer contains the actual business rules, such as checking client-project relationships and calculating invoice balances. The storage utility saves the data in JSON files, so a database is not needed for this learning version.
>
> For example, when I record a partial payment, the backend checks that the invoice exists and that the payment does not exceed the remaining balance. It saves the payment, then calculates the new balance when invoices are loaded. The dashboard uses these same records to calculate collected revenue and outstanding amounts.”

## 9. Demo order

1. Open Overview and explain the totals.
2. Open Contacts; add a lead and convert it to a client.
3. Open Projects; create a project for that client and change its status.
4. Open Invoices; create an invoice for the project.
5. Record a partial payment and point out the updated collected amount, balance, and status.
6. Open `data/clients.json`, `data/projects.json`, or `data/invoices.json` to show that the data is saved locally.

## 10. Limitations to be honest about

This is a single-user educational demo. It has no login, access controls, database transactions, automatic backups, or multi-user support. JSON storage is easy to inspect and learn from, but PostgreSQL would be a better choice for a deployed business application. The tests currently cover validation rules; they are not a full end-to-end test suite.
