const state = {
  page: "overview",
  showForm: false,
  query: "",
  clients: [],
  projects: [],
  invoices: [],
  dashboard: null
};

const content = document.querySelector("#page-content");
const title = document.querySelector("#page-title");
const notice = document.querySelector("#notice");
const paymentDialog = document.querySelector("#payment-dialog");

const money = (value) => new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0
}).format(Number(value) || 0);

const safe = (value = "") => String(value).replace(/[&<>"']/g, (character) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
}[character]));

function prettyDate(value) {
  if (!value) return "—";
  return new Date(`${value}T00:00:00`).toLocaleDateString("en-IN", {
    day: "numeric", month: "short", year: "numeric"
  });
}

function badge(value) {
  const label = String(value || "unknown").replaceAll("-", " ");
  return `<span class="badge ${safe(value)}">${safe(label)}</span>`;
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const result = await response.json();

  if (!response.ok || !result.success) {
    const fieldErrors = result.errors ? Object.values(result.errors).join(" ") : "";
    throw new Error(fieldErrors || result.message || "Request failed.");
  }

  return result;
}

function showNotice(message, isError = false) {
  notice.textContent = message;
  notice.classList.toggle("error", isError);
  notice.hidden = false;
  window.clearTimeout(showNotice.timer);
  showNotice.timer = window.setTimeout(() => { notice.hidden = true; }, 4500);
}

async function refresh() {
  try {
    const [clients, projects, invoices, dashboard] = await Promise.all([
      api("/api/clients"),
      api("/api/projects"),
      api("/api/invoices"),
      api("/api/dashboard")
    ]);

    state.clients = clients.data;
    state.projects = projects.data;
    state.invoices = invoices.data;
    state.dashboard = dashboard.data;
    render();
  } catch (error) {
    content.innerHTML = `<div class="empty-state"><strong>Could not load the workspace</strong><p>${safe(error.message)}</p><p>Check that the Express server is running, then refresh the page.</p></div>`;
  }
}

function pageHeading(heading, description, buttonLabel) {
  return `<div class="page-heading"><div><h2>${heading}</h2><p>${description}</p></div>${buttonLabel ? `<button class="button button-primary" data-action="new">+ ${buttonLabel}</button>` : ""}</div>`;
}

function statCard(icon, label, value, note) {
  return `<article class="stat-card">
    <div class="stat-top"><span>${label}</span><span class="stat-icon">${icon}</span></div>
    <div class="stat-value">${value}</div><p class="stat-note">${note}</p>
  </article>`;
}

function emptyState(titleText, description) {
  return `<div class="empty-state"><strong>${titleText}</strong><p>${description}</p></div>`;
}

function table(headers, rows, emptyTitle, emptyMessage) {
  if (!rows.length) return emptyState(emptyTitle, emptyMessage);
  return `<div class="table-wrap"><table><thead><tr>${headers.map((header) => `<th>${header}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table></div>`;
}

function renderOverview() {
  const { stats, overdueInvoices, upcomingProjects } = state.dashboard;
  const projectRows = upcomingProjects.map((project) => {
    const savedProject = state.projects.find((item) => item.id === project.id) || project;
    return `<div class="list-item"><div class="list-copy"><strong>${safe(savedProject.name)}</strong><span>${safe(savedProject.clientName || "Client")}</span></div><div class="list-value">${prettyDate(savedProject.dueDate)}<span>${badge(savedProject.status)}</span></div></div>`;
  }).join("");

  const overdueRows = overdueInvoices.map((invoice) =>
    `<div class="list-item"><div class="list-copy"><strong>${safe(invoice.invoiceNumber)} · ${safe(invoice.clientName)}</strong><span>Due ${prettyDate(invoice.dueDate)}</span></div><div class="list-value">${money(invoice.balance)}<span>${badge("overdue")}</span></div></div>`
  ).join("");

  content.innerHTML = `${pageHeading("Business at a glance", "A quick view of work in progress and money to collect.", "Add contact")}
    <div class="stats-grid">
      ${statCard("♙", "Clients", stats.clients, "People you work with")}
      ${statCard("✳", "Open leads", stats.leads, "Potential future work")}
      ${statCard("▦", "Active projects", stats.activeProjects, "Projects not yet completed")}
      ${statCard("₹", "Collected revenue", money(stats.revenueCollected), "Payments recorded so far")}
    </div>
    <div class="stats-grid stats-secondary">
      ${statCard("↗", "Outstanding", money(stats.outstanding), "Balance across all invoices")}
      ${statCard("!", "Overdue invoices", stats.overdueCount, "Invoices past their due date")}
    </div>
    <div class="content-grid">
      <section class="panel"><div class="panel-header"><div><h3>Upcoming project deadlines</h3><p>Work with a future due date</p></div><button class="button button-quiet button-small" data-goto="projects">View projects</button></div><div class="panel-body list-stack">${projectRows || emptyState("No upcoming deadlines", "Create a project to start tracking your work.")}</div></section>
      <section class="panel"><div class="panel-header"><div><h3>Needs your attention</h3><p>Invoices that have passed their due date</p></div><button class="button button-quiet button-small" data-goto="invoices">View invoices</button></div><div class="panel-body list-stack">${overdueRows || emptyState("You're all caught up", "Overdue invoices will appear here.")}</div></section>
    </div>`;
}

function renderClientForm() {
  return `<section class="form-panel"><div class="form-panel-header"><div><h3>Add a contact</h3><p>Save a potential lead or an existing client.</p></div><button class="button button-quiet button-small" data-action="cancel-form">Cancel</button></div>
    <form class="form-stack" data-form="client">
      <div class="form-grid"><label>Full name<input name="name" required maxlength="80" placeholder="e.g. Aditi Sharma"></label><label>Email address<input name="email" type="email" required maxlength="120" placeholder="aditi@example.com"></label>
      <label>Company (optional)<input name="company" maxlength="100" placeholder="Company or brand name"></label><label>Relationship<select name="type"><option value="lead">Lead</option><option value="client">Client</option></select></label></div>
      <label>Notes (optional)<input name="notes" maxlength="300" placeholder="How you met, what they need, or next steps"></label>
      <div class="form-actions"><button class="button button-primary" type="submit">Save contact</button></div>
    </form></section>`;
}

function renderClients() {
  const query = state.query.trim().toLowerCase();
  const clients = state.clients.filter((client) =>
    [client.name, client.email, client.company, client.type].join(" ").toLowerCase().includes(query)
  );
  const rows = clients.map((client) => `<tr>
    <td><div class="primary-cell">${safe(client.name)}</div><div class="secondary-cell">${safe(client.email)}</div></td>
    <td>${safe(client.company || "—")}</td><td>${badge(client.type)}</td>
    <td><div class="action-row">${client.type === "lead" ? `<button class="button button-quiet button-small" data-action="convert" data-id="${safe(client.id)}">Convert to client</button>` : `<span class="secondary-cell">Client added</span>`}</div></td>
  </tr>`);

  content.innerHTML = `${pageHeading("Contacts", "Keep leads and client details organised.", "Add contact")}
    ${state.showForm ? renderClientForm() : ""}
    <section class="panel"><div class="panel-header"><div><h3>All contacts <span class="secondary-cell">(${state.clients.length})</span></h3><p>Convert a lead when they agree to work with you.</p></div><div class="search-row"><input id="contact-search" class="search-input" type="search" value="${safe(state.query)}" placeholder="Search contacts…" aria-label="Search contacts"></div></div>
    ${table(["Contact", "Company", "Type", "Action"], rows, "No contacts found", query ? "Try a different search term." : "Add your first contact to start building a client list.")}</section>`;
}

function renderProjectForm() {
  const clients = state.clients.filter((client) => client.type === "client");
  if (!clients.length) {
    return `<section class="form-panel">${emptyState("Add a client first", "A project must belong to an existing client. Go to Contacts and convert a lead or add a client.")}<div class="form-actions"><button class="button button-quiet" data-action="cancel-form">Close</button><button class="button button-primary" data-goto="clients">Go to contacts</button></div></section>`;
  }

  return `<section class="form-panel"><div class="form-panel-header"><div><h3>Create a project</h3><p>Give the work an owner, fee, and deadline.</p></div><button class="button button-quiet button-small" data-action="cancel-form">Cancel</button></div>
    <form class="form-stack" data-form="project"><div class="form-grid">
      <label>Project name<input name="name" required maxlength="100" placeholder="e.g. Brand identity"></label>
      <label>Client<select name="clientId" required>${clients.map((client) => `<option value="${safe(client.id)}">${safe(client.name)}</option>`).join("")}</select></label>
      <label>Project fee (₹)<input name="fee" type="number" min="1" step="0.01" required placeholder="45000"></label>
      <label>Status<select name="status"><option value="planned">Planned</option><option value="in-progress">In progress</option><option value="review">In review</option><option value="on-hold">On hold</option><option value="completed">Completed</option></select></label>
      <label>Start date<input name="startDate" type="date" required></label><label>Due date<input name="dueDate" type="date" required></label>
    </div><div class="form-actions"><button class="button button-primary" type="submit">Save project</button></div></form></section>`;
}

function renderProjects() {
  const rows = state.projects.map((project) => `<tr>
    <td><div class="primary-cell">${safe(project.name)}</div><div class="secondary-cell">${safe(project.clientName)}</div></td>
    <td>${money(project.fee)}</td><td>${prettyDate(project.dueDate)}</td>
    <td><select class="inline-select" data-status-id="${safe(project.id)}" aria-label="Status for ${safe(project.name)}">${[
      ["planned", "Planned"], ["in-progress", "In progress"], ["review", "In review"], ["on-hold", "On hold"], ["completed", "Completed"]
    ].map(([value, label]) => `<option value="${value}" ${project.status === value ? "selected" : ""}>${label}</option>`).join("")}</select></td>
  </tr>`);

  content.innerHTML = `${pageHeading("Projects", "Track deliverables, fees, and deadlines by client.", "Add project")}
    ${state.showForm ? renderProjectForm() : ""}
    <section class="panel"><div class="panel-header"><div><h3>Project list</h3><p>Update a project's status directly from the table.</p></div><span class="badge">${state.projects.length} total</span></div>
    ${table(["Project / client", "Fee", "Due date", "Status"], rows, "No projects yet", "Add a client first, then create your first project.")}</section>`;
}

function renderInvoiceForm() {
  if (!state.projects.length) {
    return `<section class="form-panel">${emptyState("Create a project first", "Invoices are linked to a project so the client and work stay connected.")}<div class="form-actions"><button class="button button-quiet" data-action="cancel-form">Close</button><button class="button button-primary" data-goto="projects">Go to projects</button></div></section>`;
  }

  return `<section class="form-panel"><div class="form-panel-header"><div><h3>Create an invoice</h3><p>The invoice inherits its client from the selected project.</p></div><button class="button button-quiet button-small" data-action="cancel-form">Cancel</button></div>
    <form class="form-stack" data-form="invoice"><div class="form-grid">
      <label>Project<select name="projectId" required>${state.projects.map((project) => `<option value="${safe(project.id)}">${safe(project.name)} — ${safe(project.clientName)}</option>`).join("")}</select></label>
      <label>Invoice amount (₹)<input name="amount" type="number" min="1" step="0.01" required placeholder="25000"></label>
      <label>Issue date<input name="issueDate" type="date" required></label><label>Due date<input name="dueDate" type="date" required></label>
    </div><div class="form-actions"><button class="button button-primary" type="submit">Create invoice</button></div></form></section>`;
}

function renderInvoices() {
  const rows = state.invoices.map((invoice) => `<tr>
    <td><div class="primary-cell">${safe(invoice.invoiceNumber)}</div><div class="secondary-cell">${safe(invoice.clientName)} · ${safe(invoice.projectName)}</div></td>
    <td>${money(invoice.amount)}</td><td><div class="primary-cell">${money(invoice.paid)}</div><div class="secondary-cell">of ${money(invoice.amount)}</div></td>
    <td><div class="primary-cell">${money(invoice.balance)}</div><div class="secondary-cell">Due ${prettyDate(invoice.dueDate)}</div></td>
    <td>${badge(invoice.status)}</td>
    <td>${invoice.balance > 0 ? `<button class="button button-quiet button-small" data-action="pay" data-id="${safe(invoice.id)}">Record payment</button>` : `<span class="secondary-cell">Settled</span>`}</td>
  </tr>`);

  content.innerHTML = `${pageHeading("Invoices", "Create invoices and record full or partial payments.", "Create invoice")}
    ${state.showForm ? renderInvoiceForm() : ""}
    <section class="panel"><div class="panel-header"><div><h3>All invoices</h3><p>Outstanding balance is calculated from recorded payments.</p></div><span class="badge">${state.invoices.length} total</span></div>
    ${table(["Invoice / client", "Amount", "Collected", "Balance", "Status", "Action"], rows, "No invoices yet", "Create a project, then issue an invoice against it.")}</section>`;
}

function render() {
  const titles = { overview: "Overview", clients: "Contacts", projects: "Projects", invoices: "Invoices" };
  title.textContent = titles[state.page];
  document.querySelectorAll("[data-page]").forEach((button) => {
    button.classList.toggle("active", button.dataset.page === state.page);
  });

  if (!state.dashboard) {
    content.innerHTML = `<div class="loading">Loading your workspace…</div>`;
    return;
  }

  if (state.page === "overview") renderOverview();
  if (state.page === "clients") renderClients();
  if (state.page === "projects") renderProjects();
  if (state.page === "invoices") renderInvoices();
}

function navigate(page) {
  state.page = page;
  state.showForm = false;
  state.query = "";
  render();
}

document.addEventListener("click", async (event) => {
  const navButton = event.target.closest("[data-page], [data-goto]");
  if (navButton) {
    navigate(navButton.dataset.page || navButton.dataset.goto);
    return;
  }

  const actionButton = event.target.closest("[data-action]");
  if (!actionButton) return;

  const { action, id } = actionButton.dataset;
  if (action === "new") {
    state.showForm = true;
    if (state.page === "overview") state.page = "clients";
    render();
    return;
  }
  if (action === "cancel-form") {
    state.showForm = false;
    render();
    return;
  }
  if (action === "convert") {
    try {
      await api(`/api/clients/${encodeURIComponent(id)}/convert`, { method: "PATCH", body: "{}" });
      await refresh();
      showNotice("Contact type updated.");
    } catch (error) { showNotice(error.message, true); }
    return;
  }
  if (action === "pay") {
    const invoice = state.invoices.find((item) => item.id === id);
    if (!invoice) return;
    const form = document.querySelector("#payment-form");
    form.elements.invoiceId.value = invoice.id;
    form.elements.amount.max = invoice.balance;
    form.elements.amount.value = "";
    form.elements.date.value = new Date().toISOString().slice(0, 10);
    document.querySelector("#payment-invoice-label").textContent = `${invoice.invoiceNumber} · ${invoice.clientName} · Remaining ${money(invoice.balance)}`;
    paymentDialog.showModal();
  }
});

document.addEventListener("input", (event) => {
  if (event.target.id !== "contact-search") return;
  const cursor = event.target.selectionStart;
  state.query = event.target.value;
  renderClients();
  const replacement = document.querySelector("#contact-search");
  replacement.focus();
  replacement.setSelectionRange(cursor, cursor);
});

document.addEventListener("change", async (event) => {
  const projectId = event.target.dataset.statusId;
  if (!projectId) return;

  try {
    await api(`/api/projects/${encodeURIComponent(projectId)}/status`, {
      method: "PATCH",
      body: JSON.stringify({ status: event.target.value })
    });
    await refresh();
    showNotice("Project status updated.");
  } catch (error) {
    showNotice(error.message, true);
    await refresh();
  }
});

document.addEventListener("submit", async (event) => {
  const form = event.target.closest("form[data-form]");
  if (form) {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    const type = form.dataset.form;
    const endpoints = { client: "/api/clients", project: "/api/projects", invoice: "/api/invoices" };

    try {
      const result = await api(endpoints[type], { method: "POST", body: JSON.stringify(data) });
      state.showForm = false;
      await refresh();
      showNotice(result.message || "Saved successfully.");
    } catch (error) { showNotice(error.message, true); }
    return;
  }

  if (event.target.id === "payment-form") {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(event.target).entries());
    const invoiceId = data.invoiceId;
    delete data.invoiceId;

    try {
      await api(`/api/invoices/${encodeURIComponent(invoiceId)}/payments`, {
        method: "POST", body: JSON.stringify(data)
      });
      paymentDialog.close();
      await refresh();
      showNotice("Payment recorded successfully.");
    } catch (error) { showNotice(error.message, true); }
  }
});

document.querySelector("#close-dialog").addEventListener("click", () => paymentDialog.close());
document.querySelector("#cancel-dialog").addEventListener("click", () => paymentDialog.close());
document.querySelector("#today-label").textContent = new Date().toLocaleDateString("en-IN", {
  day: "numeric", month: "short", year: "numeric"
});

refresh();
