require("dotenv").config();

const path = require("path");
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");

const clientRoutes = require("./backend/routes/clientRoutes");
const projectRoutes = require("./backend/routes/projectRoutes");
const invoiceRoutes = require("./backend/routes/invoiceRoutes");
const dashboardRoutes = require("./backend/routes/dashboardRoutes");
const errorHandler = require("./backend/middleware/errorHandler");
const { initialiseData } = require("./backend/utils/seedData");

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware runs before the request reaches a route.
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "frontend")));

// Small health endpoint for checking whether the server is alive.
app.get("/api/health", (_req, res) => {
  res.json({ success: true, message: "FreelanceOS is running." });
});

// Each feature has its own router.
app.use("/api/clients", clientRoutes);
app.use("/api/projects", projectRoutes);
app.use("/api/invoices", invoiceRoutes);
app.use("/api/dashboard", dashboardRoutes);

app.use((req, res) => {
  res.status(404).json({ success: false, message: "API route not found." });
});

// Keep error responses in one place.
app.use(errorHandler);

// Prepare the JSON files before accepting requests.
if (require.main === module) {
  initialiseData()
    .then(() => {
      app.listen(PORT, () => {
        console.log(`FreelanceOS is ready at http://localhost:${PORT}`);
      });
    })
    .catch((error) => {
      console.error("Could not initialise data:", error);
      process.exit(1);
    });
}

module.exports = app;
