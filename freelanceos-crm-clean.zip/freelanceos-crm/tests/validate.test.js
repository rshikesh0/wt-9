const test = require("node:test");
const assert = require("node:assert/strict");
const {
  validateClient,
  validateProject,
  validateInvoice,
  isMoney,
  isDate
} = require("../backend/middleware/validate");

test("client form accepts valid data", () => {
  assert.deepEqual(validateClient({
    name: "Aditi Sharma",
    email: "aditi@example.com",
    type: "lead"
  }), {});
});

test("client form rejects a bad email and missing name", () => {
  const errors = validateClient({ name: " ", email: "not-an-email", type: "lead" });
  assert.ok(errors.name);
  assert.ok(errors.email);
});

test("project due date cannot come before its start date", () => {
  const errors = validateProject({
    name: "Portfolio website",
    clientId: "client-1",
    fee: "12000",
    startDate: "2026-10-20",
    dueDate: "2026-10-19",
    status: "planned"
  });
  assert.equal(errors.dueDate, "Due date cannot be before the start date.");
});

test("invoice amount must be positive and date must be valid", () => {
  const errors = validateInvoice({
    projectId: "project-1",
    amount: "0",
    issueDate: "2026-02-30",
    dueDate: "2026-11-01"
  });
  assert.ok(errors.amount);
  assert.ok(errors.issueDate);
});

test("money and date helpers reject invalid values", () => {
  assert.equal(isMoney("1250"), true);
  assert.equal(isMoney("-1"), false);
  assert.equal(isDate("2026-10-14"), true);
  assert.equal(isDate("14/10/2026"), false);
});
