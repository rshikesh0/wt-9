# FreelanceOS CRM

A small local CRM for a freelancer to manage leads, clients, projects, invoices, and payments. It uses the same general structure as the feedback form project, with one extra service layer to keep business rules out of HTTP handlers.

## Run it

Requirements: Node.js 20 or newer.

```bash
npm install
npm run dev
```

Open `http://localhost:3000`. `npm start` runs the same app without the development file watcher. On first startup, a few fictional demo records are added so the screens are not empty.

Run the checks with:

```bash
npm test
```

## Main features

- Add contacts as leads or clients, search them, and convert a lead into a client.
- Create projects for saved clients and track their fee, due date, and status.
- Create invoices linked to projects.
- Record multiple partial payments against an invoice.
- Calculate collected revenue, outstanding balances, and overdue invoices from saved records.
- Store data in three JSON files; no database setup is needed.

## Directory guide

```text
freelanceos-crm/
├── server.js                       # App setup and API entry point
├── frontend/
│   ├── index.html                  # Page structure
│   ├── style.css                   # Layout and visual design
│   └── app.js                      # UI events and API requests
├── backend/
│   ├── routes/                     # Maps URL + HTTP method to a controller
│   ├── controllers/                # Reads the request and sends the response
│   ├── services/crmService.js      # CRM rules and calculations
│   ├── middleware/                 # Input validation and common errors
│   └── utils/                      # JSON file storage, seed data, HTTP errors
├── data/                           # Local JSON records
├── tests/                          # Small automated validation tests
└── docs/PROJECT-WALKTHROUGH.md     # Explanation / presentation guide
```

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Confirm the server is running |
| GET, POST | `/api/clients` | List contacts or create one |
| PATCH | `/api/clients/:id/convert` | Convert a lead into a client |
| GET, POST | `/api/projects` | List projects or create one |
| PATCH | `/api/projects/:id/status` | Change a project's status |
| GET, POST | `/api/invoices` | List invoices or create one |
| POST | `/api/invoices/:id/payments` | Record a partial/full payment |
| GET | `/api/dashboard` | Return calculated dashboard figures |

## Data relationships

- One client can have many projects (`projects.clientId` points to `clients.id`).
- One project can have many invoices (`invoices.projectId` points to `projects.id`).
- One invoice can contain multiple payments in its `payments` array.
- Payment totals and remaining balances are calculated; they are not stored as separate numbers that could drift out of sync.

## Important limits

This is a learning project intended to run locally for one person. JSON files are not a replacement for a transactional database, and the app does not include login or multi-user permissions. Do not expose it publicly or store sensitive client information. A production version should use authentication, authorization, PostgreSQL transactions, backups, and stronger integration tests.
